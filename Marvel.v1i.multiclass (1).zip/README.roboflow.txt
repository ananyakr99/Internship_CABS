
Marvel - v1 2021-05-12 3:21pm
==============================

This dataset was exported via roboflow.ai on May 12, 2021 at 9:52 AM GMT

It includes 900 images.
Maritime-vessels are annotated in Multi-Class Classification format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


